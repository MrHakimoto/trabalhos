jQuery(document).ready(function(){
	// login form
	jQuery('.login-form').prepend('<i class="fa fa-lock icon"></i>');
	jQuery('.login-form .mod_login_wrapper').prepend('<i class="fa fa-close close-icon"></i>');
	
	jQuery(document).click(function(event){
		if (jQuery(event.target).closest(".login-form").length) return;
		jQuery('.login-form .mod_login_wrapper').removeClass('open');
		jQuery('.login-form i.fa.icon').removeClass('active');
		
	})
	
	jQuery('.login-form i.fa.icon').click(function(){
		if (jQuery(this).hasClass('active')) {
			jQuery('.login-form .mod_login_wrapper').removeClass('open');
			jQuery('.login-form i.fa.icon').removeClass('active');
		} else {
			jQuery('.login-form .mod_login_wrapper').addClass('open');
			jQuery('.login-form i.fa.icon').addClass('active');			
		}
	})
	
	jQuery('.login-form i.close-icon').click(function(){
		jQuery('.login-form .mod_login_wrapper').removeClass('open');
		jQuery('.login-form i.fa.icon').removeClass('active');
	})
	
	jQuery('.login-form i.close-icon').click(function(){
		jQuery('.login-form .mod_login_wrapper').removeClass('open');
		jQuery('.login-form i.fa.icon').removeClass('active');
	})
	
})